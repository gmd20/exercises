#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdio.h>
#include <fcntl.h>
#include <io.h>
#include <direct.h>// for mkdir
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>

#include "windows-mmap.h"

/**
 *  Apple iOS OTA unpacker - by Jonathan Levin,
 *  http://NewOSXBook.com/
 *
 *  Free for anyone to use, modify, etc. I won't complain :-), but I'd appreciate a mention
 *
 * Changelog: 02/08/16 - Replaced alloca with malloc () (full OTAs with too many files would have popped stack..)
 *
 *            02/17/16 - Increased tolerance for corrupt OTA - can now seek to entry in a file
 *
 *
 */
uint64_t pos = 0;
typedef unsigned int uint32_t;

#pragma pack(1)
struct entry
{

  unsigned int usually_0x210_or_0x110;
  unsigned short  usually_0x00_00; //_00_00;
  unsigned int  fileSize;
  unsigned short whatever;
  unsigned long long timestamp_likely;
  unsigned short _usually_0x20;
  unsigned short nameLen;
  unsigned short uid;
  unsigned short gid;
  unsigned short perms;

  char name[0];
  // Followed by file contents
};

#pragma pack()

inline uint32_t swap32(uint32_t arg)
{
  return _byteswap_ulong(arg);
}
inline uint16_t swap16(uint16_t arg)
{
  return _byteswap_ushort(arg);
}

int g_list = 0;
int g_verbose = 0;
char *g_extract = NULL;

#ifdef _WIN32
inline char * trim_dir_space(char * name, char *dirSep) {
  char *space = dirSep;
  while(((space - 1) >= name) && (*(space -1) == ' ')) {
    space--;
  }
  if (space != dirSep) {
    memmove(space, dirSep, strlen(dirSep) + 2);
  }
  return space;
}
#else
inline char * trim_dir_space(char * name, char *dirSep) {
  return dirSep;
}
#endif

  void
extractFile(char *File, char *Name, uint32_t Size, char *ExtractCriteria)
{
  // MAYBE extract file (depending if matches Criteria, or "*").
  // You can modify this to include regexps, case sensitivity, what not.
  // presently, it's just strstr()

  if (!ExtractCriteria) return;
  if ((ExtractCriteria[0] != '*') && !strstr(Name, ExtractCriteria)) return;

  // Ok. Extract . This is simple - just dump the file contents to its directory.
  // What we need to do here is parse the '/' and mkdir(2), etc.

  char *dirSep = strchr(Name, '/');
  while (dirSep) {
    // iPhone iOS 10.xx OTA package has a special filename in it:
    // "System/Library/PrivateFrameworks/ResponseKit.framework/ar_AE.lproj /ResponsesEditable.strings"
    // on Windows Platform the _mkdir("xx/ar_AE.lproj ") function will creates
    // the "xx/ar_AE.lproj" directory without the space
    // it may be a typo error, we need to fix it to avoid _open errors
    dirSep = trim_dir_space(Name, dirSep);

    *dirSep = '\0';
    if (ENOENT  == _mkdir(Name)) {
      fprintf(stderr, "Can not mkdir, Path was not found %s\n", Name);
      exit(1);
    }
    *dirSep = '/';
    dirSep += 1;
    dirSep = strchr(dirSep, '/');
  }

  // at this point we're out of '/'s
  // go back to the last /, if any

  if (g_verbose)
  {
    fprintf(stderr, "Dumping %d bytes to %s\n", Size, Name);
  }
  int fd = _open(Name, _O_WRONLY | _O_CREAT | _O_BINARY, _S_IREAD | _S_IWRITE);
  if (fd < 0) {
    perror(Name);
    fprintf(stderr, "failed to create file.");
    exit(1);
  }
  int bytes_written = _write(fd, File, Size);
  if (bytes_written < 0) {
    perror(Name);
    exit(1);
  }
  _close(fd);
  // _chmod(Name, _S_IREAD | _S_IWRITE);

} //  end extractFile

void showPos(int signal)
{
  fprintf(stderr, "POS is %lld\n", pos);
}
int main(int argc, char **argv)
{
  signal(SIGINT, showPos);
  char *filename = "p";
  int i = 0;

  if (argc < 2) {
    fprintf(stderr, "Usage: %s [-v] [-l] [-e file] _filename_\nWhere: -l: list files in update payload\n       -e _file: extract file from update payload (use \"*\" for all files)\n", argv[0]);
    exit(10);
  }

  for (i = 1;
      i < argc - 1;
      i++)
  {
    // This is super quick/dirty. You might want to rewrite with getopt, etc..
    if (strcmp(argv[i], "-l") == 0) { g_list++; }
    if (strcmp(argv[i], "-v") == 0) { g_verbose++; }
    if (strcmp(argv[i], "-e") == 0) { g_extract = argv[i + 1]; i++; }

  }

  filename = argv[argc - 1];
  //unsigned char buf[4096];
  int fd = _open(filename, _O_RDONLY | _O_BINARY);
  if (fd < 0) { perror(filename); exit(1); }

  // 02/17/2016 - mmap

  struct _stat64 stbuf;
  int rc = _fstat64(fd, &stbuf);  // file size overflow
  if (rc) {
    // fprintf(stderr, "could not determine filesize. errno = %d ", errno);
    perror("could not determine filesize");
    exit(1);
  }

  char *mmapped = mmap(NULL, // void *addr,
      stbuf.st_size,    // size_t len,
      PROT_READ,        // int prot,
      MAP_PRIVATE,      // int flags,
      fd,               // int fd,
      0);               // off_t offset);

  if (mmapped == MAP_FAILED) { perror("mmap"); exit(1); }
  i = 0;

  struct entry *ent = _alloca(sizeof(struct entry));

  char *name = NULL;
  uint32_t name_len = 0;
  while (pos + 3 * sizeof(struct entry) < (size_t) stbuf.st_size) {

    ent = (struct entry *) (mmapped + pos);

    pos += sizeof(struct entry);

    if ((ent->usually_0x210_or_0x110 != 0x210 && ent->usually_0x210_or_0x110 != 0x110 &&
          ent->usually_0x210_or_0x110 != 0x310) ||
        ent->usually_0x00_00)
    {
      fprintf(stderr, "Corrupt entry (0x%x at pos %llu).. skipping\n", ent->usually_0x210_or_0x110, pos);
      int skipping = 1;

      while (skipping)
      {
        ent = (struct entry *) (mmapped + pos);
        while (ent->usually_0x210_or_0x110 != 0x210 && ent->usually_0x210_or_0x110 != 0x110)
        {
          // #@$#$%$# POS ISN'T ALIGNED!
          pos++;
          ent = (struct entry *) (mmapped + pos);
        }
        // read rest of entry
        int nl = swap16(ent->nameLen);

        if (ent->usually_0x00_00 || !nl) {
          //	fprintf(stderr,"False positive.. skipping %d\n",pos);
          pos += 1;
        } else {
          skipping = 0;
          pos += sizeof(struct entry);
        }
      }
    }

    uint32_t	size = swap32(ent->fileSize);

    // fprintf(stdout," Here - ENT at pos %d: %x and 0 marker is %x namelen: %d, fileSize: %d\n", pos, ent->usually_0x210_or_0x110, ent->usually_0x00_00, ntohs(ent->nameLen), size);

    uint32_t	nameLen = swap16(ent->nameLen);
    // Get Name (immediately after the entry)
    //
    // 02/08/2016: Fixed this from alloca() - the Apple jumbo OTAs have so many files in them (THANKS GUYS!!)
    // that this would exceed the stack limits (could solve with ulimit -s, or also by using
    // a max buf size and reusing same buf, which would be a lot nicer)

    // Note to AAPL: Life would have been a lot nicer if the name would have been NULL terminated..
    // What's another byte per every file in a huge file such as this?
    // char *name = (char *) (mmapped+pos);
    if (name == NULL) {
      name = malloc(nameLen + 1);
      name_len = nameLen + 1;
    } else if (name_len < nameLen + 1) {
      free(name);
      name = malloc(nameLen + 1);
      name_len = nameLen + 1;
    }

    memcpy(name, mmapped + pos, nameLen);
    name[nameLen] = '\0';
    //printf("NAME IS %s\n", name);

    pos += swap16(ent->nameLen);
    if (g_list) {
      if (g_verbose) {
        printf("Entry @0x%d: UID: %d GID: %d Size: %d (0x%x) Namelen: %d Name: ", i,
            swap16(ent->uid), swap16(ent->gid),
            size, size,
            swap16(ent->nameLen));
      }
      printf("%s\n", name);
    }

    // Get size (immediately after the name)
    uint32_t	fileSize = swap32(ent->fileSize);
    if (fileSize)
    {
      if (g_extract) { extractFile(mmapped + pos, name, fileSize, g_extract); }
      pos += fileSize;
    }

  } // Back to loop

  _close(fd);
}
