#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <io.h>

// Changelog:
// 02/17/2016 - Fixed so it works with Apple TV OTA PBZX

typedef unsigned long long uint64_t;

#define PBZX_MAGIC	"pbzx"

#ifdef _WIN32
#define __builtin_bswap64(x)   _byteswap_uint64(x)
#endif

int main(int argc, const char * argv[])
{

  // Dumps a pbzx to stdout. Can work as a filter if no argument is specified

  char buffer[1024];
  int fd = 0;
  int minChunk = 0;

  if (argc < 2) {
    fd  = _fileno(stdin);
  } else {
    fd = _open(argv[1], _O_RDONLY | _O_BINARY);
    if (fd < 0) {
      perror (argv[1]);
      exit(5);
    }
  }
  if (-1 == _setmode(fd, _O_BINARY)) {
    fprintf(stderr, "Can't set stdin file mode _O_BINARY.\n");
    exit(1);
  }
  if (-1 == _setmode(_fileno(stdout), _O_BINARY)) {
    fprintf(stderr, "Can't set stdout file mode _O_BINARY.\n");
    exit(1);
  }
  if (argc == 3) {
    minChunk = atoi(argv[2]);
    fprintf(stderr,"Starting from Chunk %d\n", minChunk);
  }

  _read(fd, buffer, 4);
  if (memcmp(buffer, PBZX_MAGIC, 4)) {
    fprintf(stderr, "Can't find pbzx magic\n");
    exit(1);
  }

  // Now, if it IS a pbzx

  uint64_t length = 0, flags = 0;

  _read (fd, &flags, sizeof (uint64_t));
  flags = __builtin_bswap64(flags);

  fprintf(stderr,"Flags: 0x%llx\n", flags);

  int i = 0;
  int off = 0;

  int warn = 0 ;
  int skipChunk = 0;

  char *buf = NULL;
  uint64_t buf_len = 0;

  while (flags & 0x01000000) { // have more chunks
    i++;
    int read_len = 0;
    read_len = _read (fd, &flags, sizeof (uint64_t));
    if (read_len != sizeof(uint64_t)) {
      fprintf(stderr, "Warning: Can't read file %d != %llu.\n", read_len, sizeof(uint64_t));
      exit(1);
    }
    flags = __builtin_bswap64(flags);
    read_len = _read (fd, &length, sizeof (uint64_t));
    if (read_len != sizeof(uint64_t)) {
      fprintf(stderr, "Warning: Can't read file %d != %llu.\n", read_len, sizeof(uint64_t));
      exit(1);
    }
    length = __builtin_bswap64(length);

    skipChunk = (i < minChunk);
    fprintf(stderr,"Chunk #%d (flags: %llx, length: %llu bytes) %s\n",i, flags,length,
        skipChunk? "(skipped)":"");

    // Let's ignore the fact I'm allocating based on user input, etc..
    if (buf == NULL) {
      buf = malloc(length);
      buf_len = length;
    } else if (buf_len < length) {
      free(buf);
      buf = malloc(length);
      buf_len = length;
    }

    read_len = _read (fd, buf, length);
    if (read_len != length) {
      fprintf(stderr, "Warning: Can't read file %d != %llu.\n", read_len, length);
      exit(1);
    }
    // We want the XZ header/footer if it's the payload, but prepare_payload doesn't have that,
    // so just warn.

    if (memcmp(buf, "\xfd""7zXZ", 6))  {
      warn++;
      fprintf (stderr, "Warning: Can't find XZ header. Instead have 0x%x(?).. This is likely not XZ data.\n",
          (* (uint32_t *) buf ));

    } else if (strncmp(buf + length -2, "YZ", 2)) { // if we have the header, we had better have a footer, too
      warn++;
      fprintf (stderr, "Warning: Can't find XZ footer. This is bad.\n");
    }
    if (!warn && !skipChunk) {
      _write (_fileno(stdout), buf, length);
    }
    warn = 0;
  }
  return 0;
}
